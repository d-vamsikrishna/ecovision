<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="dashboard-styles.css">
  <title>Dashboard</title>
</head>
<body>
  <div class="dashboard-header">
    <div class="company-name">Eco Vision</div>
    <div class="logout">
      <a href="index.php"><button>Logout</button></a>
    </div>
  </div>
  <div class="dashboard-content">
    <div class="greeting">
      <?php
      session_start();
if(isset($_SESSION['variableToSend'])) {
    $receivedVariable = $_SESSION['variableToSend'];
    $servername = "localhost";
$username = "newuser";
$password = "gagan45";
$db = "ecovision";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $db);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT name,points FROM details where email='$receivedVariable'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "Hi, " . $row['name']."<br> points:" . $row['points'];
  }
} 
}
?></div>
    <div class="dashboard-links">
      <a href="page1.php?variableName=<?php echo urlencode($receivedVariable); ?>">
        <img src="d2.jpg" alt="Image 1">
        <div class="link-overlay">IOT</div>
      </a>
      <a href="fooddonation1.php">
        <img src="food.jpg" alt="Image 2">
        <div class="link-overlay">Food Donation</div>
      </a>
      <a href="campaign2.php">
        <img src="campaign.jpg" alt="Image 3">
        <div class="link-overlay">Campaign</div>
      </a>
      <a href="videos.php">
        <img src="vedios.jpg" alt="Image 4">
        <div class="link-overlay">Videos</div>
      </a>
    </div>
  <!-- ... remaining HTML ... -->
  <!-- ... remaining HTML ... -->
</body>
</html>