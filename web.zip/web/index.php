
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Eco Vision - Waste Management</title>
<style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    color: #fff;
    background-image: url('main1.jpg');
    background-repeat: no-repeat;
    background-size: 100%;
  }
  h1{
    font-size:50px;
  }
  .header {
    background-color: #333;
    color: #fff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
  }
  h1{
    margin-top: 25%;
  }
  .company-name {
    font-size: 24px;
    font-weight: bold;
  }

  .nav-buttons {
    display: flex;
    gap: 10px;
  }

  .nav-button {
    background-color: #4CAF50;
    color: white;
    border: none;
    padding: 10px 20px;
    cursor: pointer;
    border-radius: 5px;
    text-align: center;
    text-decoration: none;
    font-size: 16px;
  }
  p{
    font-size: 20px;
  }

  .content {
    padding: 20px;
    max-width: 800px;
    margin: 0 auto;
  }

</style>
</head>
<body>
  <div class="header">
    <div class="company-name">Eco Vision</div>
    <div class="nav-buttons">
      <button class="nav-button" onclick="window.location.href='login1.php'">Login</button>
      <button class="nav-button" onclick="window.location.href='registration1.php'">Register</button>
    </div>
  </div>
  <div class="content">
    <h1>Empowering Sustainable Waste Management </h1>
    <p>
      The Ecovision primary goal is to establish a holistic waste management system, mitigating health and pollution issues from improper waste handling. This entails deploying IoT-enabled bins to enhance waste collection efficiency, optimizing transportation processes, utilizing IoT and machine learning for effective waste sorting, and adopting sustainable waste management practices. By doing so, the project not only addresses environmental concerns but also promotes public health by reducing the adverse impacts of inadequate waste management on communities and the ecosystem.
    </p>
  </div>
</body>
</html>



