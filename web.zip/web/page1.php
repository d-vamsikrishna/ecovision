<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="page1-styles.css">
  <title>Page 1</title>
</head>
<body>
  <div class="dashboard-background">
    <div class="dashboard-header">
      <div class="company-name">Eco Vision</div>
      <div class="logout">
        <a href="index.php"><button>Logout</button></a>
      </div>
    </div>
    <div class="dashboard-content">
      <div class="greeting" id="usernameGreeting"><?php
      session_start();
      $receivedVariable="";
    if (isset($_SESSION['variableToSend'])) {
       $receivedVariable=$_SESSION['variableToSend'];
   
    }
    else if(isset($_SESSION['variableName'])){
      $receivedVariable = $_SESSION['variableName'];
    }
// Now you can use $receivedVariable in your PHP code
    $servername = "localhost";
$username = "newuser";
$password = "gagan45";
$db = "ecovision";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $db);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT name,points FROM details where email = '$receivedVariable' ";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "Hi, ".$row['name']."<br>points:" . $row['points'];
  }
}
?>
</div>
      <div class="buttons">
        <a href="complaints1.php" class="button button1">Complaints</a>
        <a href="eme_was_coll1.php" class="button button2">Emergency Waste Collection</a>
        <a href="IoT1.php" class="button button3">IoT Binsetup</a>
      </div>
    </div>
  </div>
  <script src="dashboard.js"></script>
</body>
</html>
