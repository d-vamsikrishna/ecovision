import tkinter as tk
import webbrowser
import math
from itertools import permutations
import os

# Create a Tkinter window
window = tk.Tk()
window.title("Bin Routing System")

# Create frames for organization
input_frame = tk.Frame(window)
input_frame.pack(padx=20, pady=20)

# Global variables
bins = []

# Function to add a bin
def add_bin():
    latitude = float(entry_latitude.get())
    longitude = float(entry_longitude.get())
    trash_level = int(entry_trash_level.get())
    bins.append((latitude, longitude, trash_level))
    list_bins.insert(tk.END, f"Location: {latitude}, {longitude}, Trash Level: {trash_level}")
    
    # Clear the data entry boxes
    entry_latitude.delete(0, tk.END)
    entry_longitude.delete(0, tk.END)
    entry_trash_level.delete(0, tk.END)

# Function to generate the optimized route using Nearest Neighbor TSP
def generate_route():
    trash_limit = 80
    selected_bins = [bin for bin in bins if bin[2] > trash_limit]
    locations = [(bin[0], bin[1]) for bin in selected_bins]
    
    min_distance = float('inf')
    best_route = None
    
    for start_idx in range(len(locations)):
        visited = [False] * len(locations)
        current_idx = start_idx
        route = [current_idx]
        total_distance = 0
        
        for _ in range(len(locations) - 1):
            visited[current_idx] = True
            nearest_distance = float('inf')
            nearest_idx = None
            
            for i, (lat, lon) in enumerate(locations):
                if not visited[i]:
                    distance = calculate_distance(locations[current_idx], (lat, lon))
                    if distance < nearest_distance:
                        nearest_distance = distance
                        nearest_idx = i
            
            total_distance += nearest_distance
            current_idx = nearest_idx
            route.append(current_idx)
        
        if total_distance < min_distance:
            min_distance = total_distance
            best_route = route
    
    final_route = [locations[idx] for idx in best_route]
    

    # Generate HTML file with the optimized route
    generate_html(final_route)

# Function to calculate the distance between two points
def calculate_distance(point1, point2):
    lat1, lon1 = point1
    lat2, lon2 = point2
    # Using Haversine formula for great-circle distance
    radius = 6371  # Earth's radius in kilometers
    
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2) * math.sin(dlat / 2) + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2) * math.sin(dlon / 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    distance = radius * c
    return distance




# Function to generate HTML file with the optimized route
def generate_html(route):
    with open("route.html", "w") as html_file:
        html_file.write("<html>\n")
        html_file.write("<head>\n")
        html_file.write("<title>Optimized Route</title>\n")
        html_file.write("<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/leaflet.css' />\n")
        html_file.write("<style>html, body { height: 100%; margin: 0; }</style>\n")
        html_file.write("</head>\n")
        html_file.write("<body>\n")
        html_file.write("<div id='map' style='width: 100%; height: 100%;'></div>\n")
        html_file.write("<script src='https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/leaflet.js'></script>\n")
        html_file.write("<script>\n")
        html_file.write("var map = L.map('map').setView([51.5074, -0.1278], 10);\n")
        html_file.write("L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {\n")
        html_file.write("    attribution: 'Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors'\n")
        html_file.write("}).addTo(map);\n")
        
        html_file.write("var coordinates = [\n")
        for i, location in enumerate(route):
            html_file.write(f"    [{location[0]}, {location[1]}]")
            if i != len(route) - 1:
                html_file.write(",\n")
            else:
                html_file.write("\n")
        html_file.write("];\n")
        
        html_file.write("var polyline = L.polyline(coordinates, {color: 'red'}).addTo(map);\n")
        html_file.write("map.fitBounds(polyline.getBounds());\n")
        
        # Draw lines connecting the points in the order they appear in the route
        html_file.write("var lines = [\n")
        for i in range(len(route) - 1):
            html_file.write(f"    [{route[i][0]}, {route[i][1]}], [{route[i+1][0]}, {route[i+1][1]}]")
            if i != len(route) - 2:
                html_file.write(",\n")
            else:
                html_file.write("\n")
        html_file.write("];\n")
        
        html_file.write("for (var i = 0; i < lines.length; i++) {\n")
        html_file.write("    L.polyline([lines[i][0], lines[i][1]], {color: 'blue'}).addTo(map);\n")
        html_file.write("}\n")
        
        html_file.write("</script>\n")
        html_file.write("</body>\n")
        html_file.write("</html>\n")

# Define fonts
font_bold = ("Helvetica", 12, "bold")
font_normal = ("Helvetica", 12)

# Create GUI elements
label_latitude = tk.Label(input_frame, text="Latitude:", font=font_bold)
label_latitude.grid(row=0, column=0, sticky="w")
entry_latitude = tk.Entry(input_frame, font=font_normal)
entry_latitude.grid(row=0, column=1)

label_longitude = tk.Label(input_frame, text="Longitude:", font=font_bold)
label_longitude.grid(row=1, column=0, sticky="w")
entry_longitude = tk.Entry(input_frame, font=font_normal)
entry_longitude.grid(row=1, column=1)

label_trashlevel = tk.Label(input_frame, text="Trash Level:", font=font_bold)
label_trashlevel.grid(row=2, column=0, sticky="w")
entry_trash_level = tk.Entry(input_frame, font=font_normal)
entry_trash_level.grid(row=2, column=1)

button_add_bin = tk.Button(input_frame, text="Add Bin", command=add_bin, font=font_bold)
button_add_bin.grid(row=3, columnspan=2)

list_bins = tk.Listbox(input_frame, font=font_normal)
list_bins.grid(row=4, columnspan=2, pady=10)

button_generate_route = tk.Button(input_frame, text="Start Route", command=generate_route, font=font_bold)
button_generate_route.grid(row=5, columnspan=2, pady=10)

# Start the Tkinter event loop
window.mainloop()
